<div id="besclwp-live-search-container">
    <input type="text" class="besclwp-live-search-box" placeholder="<?php esc_attr_e('Enter a keyword...', 'besclwpcpt'); ?>" />
    <div class="besclwp-live-search-icon"></div>
</div>
<div id="besclwp-no-results-message"><?php esc_attr_e('No results found.', 'besclwpcpt'); ?></div>