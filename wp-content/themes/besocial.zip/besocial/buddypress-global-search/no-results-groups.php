<div id="message" class="warning">
    <p><?php _e( 'No groups found!', 'besocial' ); ?></p>
</div>