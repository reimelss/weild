<div class="besocial-global-search-box">
    <h6>
        <a href="<?php bbp_topic_permalink(get_the_ID()); ?>"><?php bbp_topic_title(get_the_ID()); ?></a>
    </h6>
    <p>
        <?php echo buddyboss_global_search_reply_intro( 100 );?>
    </p>
</div>