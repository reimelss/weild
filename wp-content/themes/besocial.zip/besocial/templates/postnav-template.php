<div class="besclwp-single-post-nav">
    <div class="besclwp-single-post-row">
        <div class="besclwp-single-post-left">
            <?php previous_post_link('<span>%link</span>'); ?>
        </div>
        <div class="besclwp-single-post-right">
            <?php next_post_link('<span>%link</span>'); ?>
        </div>
    </div> 
</div>