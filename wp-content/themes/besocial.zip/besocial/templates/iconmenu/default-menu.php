<?php
get_template_part( 'templates/iconmenu/' . 'activity', 'menu');
get_template_part( 'templates/iconmenu/' . 'profile', 'menu');
get_template_part( 'templates/iconmenu/' . 'notifications', 'menu');
get_template_part( 'templates/iconmenu/' . 'messages', 'menu');
get_template_part( 'templates/iconmenu/' . 'friends', 'menu');
get_template_part( 'templates/iconmenu/' . 'groups', 'menu');
get_template_part( 'templates/iconmenu/' . 'forums', 'menu');
get_template_part( 'templates/iconmenu/' . 'settings', 'menu');
?>