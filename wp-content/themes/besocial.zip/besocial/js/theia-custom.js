jQuery(window).load(function() { "use strict";
    document.body.clientWidth >= besclwp_sticky_vars.besclwp_sticky_breakpoint && "none" !== besclwp_sticky_vars.besclwp_sticky_behavior && jQuery("#besocial-content-inner").find(".besclwp-page-right").theiaStickySidebar({ additionalMarginTop: besclwp_sticky_vars.besclwp_sticky_top, additionalMarginBottom: besclwp_sticky_vars.besclwp_sticky_bottom, sidebarBehavior: besclwp_sticky_vars.besclwp_sticky_behavior }), jQuery("#besocial-content-inner").find(".besclwp-faq-left").theiaStickySidebar({ additionalMarginTop: besclwp_sticky_vars.besclwp_sticky_top, additionalMarginBottom: besclwp_sticky_vars.besclwp_sticky_bottom, sidebarBehavior: besclwp_sticky_vars.besclwp_sticky_behavior }), jQuery("#buddypress").find("#item-nav").theiaStickySidebar({ additionalMarginTop: besclwp_sticky_vars.besclwp_sticky_top, additionalMarginBottom: besclwp_sticky_vars.besclwp_sticky_bottom, sidebarBehavior: besclwp_sticky_vars.besclwp_sticky_behavior }) }), jQuery(window).on("resize orientationchange", function() { "use strict";
    document.body.clientWidth >= besclwp_sticky_vars.besclwp_sticky_breakpoint ? (jQuery(".theiaStickySidebar").contents().unwrap(), setTimeout(function() { "none" !== besclwp_sticky_vars.besclwp_sticky_behavior && jQuery("#besocial-content-inner").find(".besclwp-page-right").theiaStickySidebar({ additionalMarginTop: besclwp_sticky_vars.besclwp_sticky_top, additionalMarginBottom: besclwp_sticky_vars.besclwp_sticky_bottom, sidebarBehavior: besclwp_sticky_vars.besclwp_sticky_behavior }), jQuery("#besocial-content-inner").find(".besclwp-faq-left").theiaStickySidebar({ additionalMarginTop: besclwp_sticky_vars.besclwp_sticky_top, additionalMarginBottom: besclwp_sticky_vars.besclwp_sticky_bottom, sidebarBehavior: besclwp_sticky_vars.besclwp_sticky_behavior }), jQuery("#buddypress").find("#item-nav").theiaStickySidebar({ additionalMarginTop: besclwp_sticky_vars.besclwp_sticky_top, additionalMarginBottom: besclwp_sticky_vars.besclwp_sticky_bottom, sidebarBehavior: besclwp_sticky_vars.besclwp_sticky_behavior }) }, 100)) : jQuery(".theiaStickySidebar").contents().unwrap() 


});

(function ($) {

	// 10 Energy
	$("[value^='10 Energy']").change(function () {
    $("[value^='1010']").prop('checked', $(this).prop("checked"));
	})

	// 15 Materials
	$("[value^='15 Materials']").change(function () {
    $("[value^='1510']").prop('checked', $(this).prop("checked"));
	})

	// 20 Industrials
	$("[value^='20 Industrials']").change(function () {
    $("[value^='2010'], [value^='2020'], [value^='2030'], [value^='2040'], [value^='2050']").prop('checked', $(this).prop("checked"));
	})

	// 25 Consumer Discretionary
	$("[value^='25 Consumer Discretionary']").change(function () {
    $("[value^='2510'], [value^='2520'], [value^='2530'], [value^='2540'], [value^='2550']").prop('checked', $(this).prop("checked"));
	})

	// 30 Consumer Staples
	$("[value^='30 Consumer Staples']").change(function () {
    $("[value^='3010'], [value^='3020'], [value^='3030']").prop('checked', $(this).prop("checked"));
	})

	// 35 Health Care
	$("[value^='35 Health Care']").change(function () {
    $("[value^='3510'], [value^='3520'], [value^='356']").prop('checked', $(this).prop("checked"));
	})

	// 40 Financials
	$("[value^='40 Financials']").change(function () {
    $("[value^='4010'], [value^='4020'], [value^='4030']").prop('checked', $(this).prop("checked"));
	})

	// 45 Information Technology
	$("[value^='45 Information Technology']").change(function () {
    $("[value^='4510'], [value^='4520'], [value^='4530']").prop('checked', $(this).prop("checked"));
	})

	// 50 Communication Services
	$("[value^='50 Communication Services']").change(function () {
    $("[value^='5010'], [value^='5020']").prop('checked', $(this).prop("checked"));
	})

	// 55 Utilities
	$("[value^='55 Utilities']").change(function () {
    $("[value^='5510']").prop('checked', $(this).prop("checked"));
	})

	// 60 Real Estate
	$("[value^='60 Real Estate']").change(function () {
    $("[value^='6010']").prop('checked', $(this).prop("checked"));
	})

	// Product Expertise
	
	

	// ECM (Equity Capital Markets)
	$("[value^='ECM (Equity Capital Markets)']").change(function () {
    $("[value^='Equity Syndicate'], [value^='IPO'], [value^='Convertible Securities'], [value='Follow-on'], [value^='PIPEs'], [value^='Registered Directs'], [value^='Agented'], [value^='Underwritten']").prop('checked', $(this).prop("checked"));

    })

    // Follow On
	$("[value='Follow-on']").change(function () {
    $("[value^='PIPEs'], [value^='Registered Directs'], [value^='Agented'], [value^='Underwritten']").prop('checked', $(this).prop("checked"));
	})

	


})(jQuery);

