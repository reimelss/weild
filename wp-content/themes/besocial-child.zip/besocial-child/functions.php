<?php
function besclwp_theme_styles()  
{  
    $besclwp_sharing_css_check = get_option('besclwp_remove_sharing');
    $besclwp_lightbox_css_check = get_option('besclwp_lightbox');
    $besclwp_post_format_css_check = get_post_format();
    
    wp_enqueue_style('normalize', get_template_directory_uri() . '/css/normalize.css', true, '1.0');
    wp_enqueue_style('fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', false, '4.6.3');
    wp_enqueue_style('slick', get_template_directory_uri() . '/css/slick.css', false, '4.6.3');
    if (empty($besclwp_sharing_css_check) && ($besclwp_sharing_css_check != 'true') && is_single()) {
        wp_enqueue_style('rrssb', get_template_directory_uri() . '/css/rrssb.css', false, '4.6.3');
    }
    if (empty($besclwp_lightbox_css_check) && ($besclwp_lightbox_css_check != 'true') && ($besclwp_post_format_css_check == 'gallery')) {
        wp_enqueue_style('featherlight', get_template_directory_uri() . '/css/featherlight.css', false, '1.5.0');
    }
    wp_enqueue_style('selectric', get_template_directory_uri() . '/css/selectric.css', false, '1.11.0');
    wp_enqueue_style('besclwp-style', get_template_directory_uri() . '/style.css', false, wp_get_theme()->get('Version'));
    wp_enqueue_style( 'besclwp-child-style', get_stylesheet_directory_uri() . '/style.css', array( 'besclwp-style' ), wp_get_theme()->get('Version'));
}

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

// END ENQUEUE PARENT ACTION
