<form role="search" method="get" class="besocial-searchbox" action="<?php echo esc_url(home_url( '/' )); ?>">
    <input type="text" class="besocial-searchtext" placeholder="<?php esc_html_e('Search...', 'besocial'); ?>" name="s" />
    <input type="submit" class="fa-input" name="submit" value="&#xf002;"  />
</form>