<div id="message" class="warning">
    <p><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'besocial' ); ?></p>
</div>