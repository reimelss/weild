<div class="besocial-global-search-box">
    <p>
        <?php echo buddyboss_global_search_reply_intro( 100 );?>
    </p>
</div>