<div class="besocial-global-search-box">
    <h6>
        <a href="<?php bbp_forum_permalink( get_the_ID()); ?>"><?php bbp_forum_title(get_the_ID()); ?></a>
    </h6>
    <p>
        <?php bbp_forum_content(get_the_ID());?>
    </p>
</div>